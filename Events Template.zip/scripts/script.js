let items = [];
const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
start_time = 'AM';
end_time = 'AM';
getData();


async function getData() {
    const response = await fetch('http://nmdcamediadev.wpengine.com/wp-json/tribe/events/v1/events', { mode: 'cors'});
    //const response = await fetch('https://feeds.simplecast.com/54nAGcIl', { mode: 'cors'});
    const data = await response.json();
    
    images = []
    descriptions = []
    start_dates = []
    start_date_details = []
    end_dates = []
    end_date_details = []
    venues = []
    
    events = data.events;
    events = Array.from(events);
    for(i = 0; i < events.length; i++) {
        console.log(events[i]);
        images.push(events[i].image.url);
        descriptions.push(events[i].description);
        start_dates.push(events[i].start_date);
        end_dates.push(events[i].end_date);
        start_date_details.push(events[i].start_date_details);
        end_date_details.push(events[i].end_date_details);
        venues.push(events[i].venue);
    }
        
    htmlCarousel = `
            <div id="eventsTitle">
                Events
            </div>
            <div id="carouselSlides" class="carousel slide carousel-fade .bg-dark" data-bs-ride="carousel" data-bs-interval="15000">
              <div class="carousel-inner">
                <div id="item0" class="carousel-item active">
                </div>
        `;
    htmlCarouselEnd = `
                </div>
            </div>
        `;
    for(i = 0; i < events.length; i++) {
        htmlCarousel += `
                <div id="item${i+1}" class="carousel-item">
                </div>
        `;
    }
    
    htmlCarousel += htmlCarouselEnd;
    
    document.querySelector("#main").innerHTML = htmlCarousel;

    for(i = 0; i < events.length; i++) {
        idString = '#item' + i;
        if(parseInt(start_date_details[i].hour) >= 12) {
            if(parseInt(start_date_details[i].hour) == 12) {
                    start_time = parseInt(start_date_details[i].hour) + ":" + start_date_details[i].minutes + ' PM';  
            } else {
                    start_time = (parseInt(start_date_details[i].hour) - 12)+ ":" + start_date_details[i].minutes + ' PM';   
                }
            } else {
                start_time = parseInt(start_date_details[i].hour)+ ":" + start_date_details[i].minutes + ' AM';
            }

        if(parseInt(end_date_details[i].hour) >= 12) {
            if(parseInt(end_date_details[i].hour) == 12) {
                    end_time = parseInt(end_date_details[i].hour) + ":" + end_date_details[i].minutes + ' PM';  
            } else {
                    end_time = (parseInt(end_date_details[i].hour) - 12) + ":" + end_date_details[i].minutes + ' PM';   
                }
            } else {
                end_time = parseInt(end_date_details[i].hour) + ":" + end_date_details[i].minutes + ' AM';
            }

        htmlDescription = descriptions[i];
        htmlImage = `
                <img id="eventImg" src="${images[i]}" alt="Image" class="fade-in">
            `;
        htmlVenue = venues[0].venue;
        htmlDate = `
                <p id="dateTime"> ${dayNames[new Date(start_dates[i]).getDay()]}, ${monthNames[new Date(start_dates[i]).getDate()]} ${parseInt(start_date_details[i].day, 10)} <span id="bracket">|</span> 
                ${start_time} - ${end_time}
                </p>
            `;
        htmlCarouselInsert = `
        
                    <div class="alignText">
                        <div id="activities">
                            <p id="activitiesTitle">ACTIVITIES</p>
                            <p id="dateTime">${htmlDate}</p>
                        </div>
                    </div>
                    <div id="location"> <p id="locationText">${htmlVenue}</p></div>
                    <div class="alignText">
                        <div id="eventContent">
                            ${htmlDescription}
                        </div>
                    </div>
                    <div id="eventImage">
                        ${htmlImage}
                    </div>
        `;
        document.querySelector(idString).innerHTML = htmlCarouselInsert;
    }
}

function showItem(index) {

}
